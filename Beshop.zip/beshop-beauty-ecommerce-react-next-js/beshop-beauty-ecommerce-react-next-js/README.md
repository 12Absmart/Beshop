# Beshop Next App

## Preview

Preview the example live on [Beshop](https://beshop-front.vercel.app/):

```
Run production build with:

bash
npm run build
npm run start
# or
yarn build
yarn start
```
